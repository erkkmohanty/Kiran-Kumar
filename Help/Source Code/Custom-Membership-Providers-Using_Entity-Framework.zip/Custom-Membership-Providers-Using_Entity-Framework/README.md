READ ME
--------

This is an implementation of custom membership providers to achieve complete control of the process 
of authenticating users, at the sametime use asp.net mvc (3)'s powerful implementation of membership 
providers. 

PS: This is the entity framework based implementation of custom membership providers available at 
http://www.codeproject.com/Articles/165159/Custom-Membership-Providers.
